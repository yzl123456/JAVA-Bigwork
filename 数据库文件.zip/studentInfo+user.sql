/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50716
Source Host           : localhost:3306
Source Database       : jpa

Target Server Type    : MYSQL
Target Server Version : 50716
File Encoding         : 65001

Date: 2016-12-20 15:28:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `studentinfo`
-- ----------------------------
DROP TABLE IF EXISTS `studentinfo`;
CREATE TABLE `studentinfo` (
  `ID` int(11) NOT NULL,
  `stuId` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `bornDate` datetime DEFAULT NULL,
  `chinese` float DEFAULT NULL,
  `math` float DEFAULT NULL,
  `english` float DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of studentinfo
-- ----------------------------
INSERT INTO `studentinfo` VALUES ('8', '11223301', 'aaa', '男', '1991-12-04 00:00:00', '80', '98', '79');
INSERT INTO `studentinfo` VALUES ('9', '11223302', 'bbb', '女', '1991-02-13 00:00:00', '78', '98', '24');
INSERT INTO `studentinfo` VALUES ('10', '11223303', 'cf', '男', '1990-01-01 00:00:00', '66', '99', '77');
INSERT INTO `studentinfo` VALUES ('11', '11223304', 'ddd', '男', '1950-01-08 00:00:00', '77', '85', '80');
INSERT INTO `studentinfo` VALUES ('12', '11223305', 'eee', '女', '1999-12-01 00:00:00', '90', '90', '99');
INSERT INTO `studentinfo` VALUES ('13', '11223306', 'ffff', '女', '1917-08-05 00:00:00', '70', '80', '90');
INSERT INTO `studentinfo` VALUES ('15', '11223308', 'hhh', '女', '1991-02-28 00:00:00', '80', '68', '78');
INSERT INTO `studentinfo` VALUES ('17', '11223310', 'jjj', '男', '2015-10-01 00:00:00', '65', '80', '55');
INSERT INTO `studentinfo` VALUES ('20', '11223311', 'iii', '男', '2011-12-15 00:00:00', '5', '90', '5');
INSERT INTO `studentinfo` VALUES ('22', '15', 'jjj', '女', '1991-08-06 00:00:00', '78', '88', '99');
INSERT INTO `studentinfo` VALUES ('688128', '16', 'kkk', '女', '1997-08-06 00:00:00', '88', '88', '88');
INSERT INTO `studentinfo` VALUES ('688129', '18', 'ggg', '女', '1995-08-06 00:00:00', '69', '99', '77');
INSERT INTO `studentinfo` VALUES ('688130', '19', 'hhh', '女', '1993-08-06 00:00:00', '97', '97', '97');
INSERT INTO `studentinfo` VALUES ('688131', '21', '应泽林', '男', '1997-06-10 00:00:00', '99', '56', '33');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5string` varchar(255) DEFAULT NULL,
  `secretkey` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'C4CA4238A0B923820DCC509A6F75849B', 'GI4DGNRWGQ3TEOBWGYZDONBTHA', 'admin');
INSERT INTO `user` VALUES ('2', '511B0D5F341BDDBD9A5348923B48D14C', 'HAZDMMJVHA3DIMRUG43TEMJRGI', 'a');
INSERT INTO `user` VALUES ('3', 'F9416A6915E35855B34E9C231EE7EB69', 'G42TOOBVGQZTONRRHAZDCMZUG4', 'b');
INSERT INTO `user` VALUES ('4', 'C4CB7AB3CAC4FD839D6C9672D864FC33', 'GQ3DMMZYHAZDIMJRGY3TGMZUGE', 'c');
INSERT INTO `user` VALUES ('5', 'DD519D639BF513452F071347573D6BB4', 'G42DKMZYHA3TMNZUGYYTQMZVG4', 'd');
INSERT INTO `user` VALUES ('6', '80AB3494EF51F56385B4B6198E66E6D5', 'GU3TONJWGIZDINJUGI4DINBUGE', 'yzl');
